const dragonImage=document.querySelector('.dragonimg')
const textInfo1=document.querySelector('.dragon-text')

dragonImage.addEventListener('click', function(event){

    if(textInfo1.style.display==="block"){
        textInfo1.style.display="none";
    }
    else{
        textInfo1.style.display="block";
    }
});

const spacexImage=document.querySelector('.spaceximg')
const textInfo2=document.querySelector('.spacex-text')

spacexImage.addEventListener('click', function(event){

    if(textInfo2.style.display==="block"){
        textInfo2.style.display="none";
    }
    else{
        textInfo2.style.display="block";
    }
});

const spacecraftImage=document.querySelector('.spacecraftimg')
const textInfo3=document.querySelector('.spacecraft-text')

spacecraftImage.addEventListener('click', function(event){

    if(textInfo3.style.display==="block"){
        textInfo3.style.display="none";
    }
    else{
        textInfo3.style.display="block";
    }
});
